To install:

1) chrome://extensions/
2) click "[+] Developer Mode" in top right
3) "Load unpacked extension..."
4) pick $GOROOT/misc/chrome/gophertool

Done.  It'll now auto-reload from source.
